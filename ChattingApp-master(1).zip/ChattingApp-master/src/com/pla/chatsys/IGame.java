package com.pla.chatsys;

public interface IGame {
	
	
	public void startGame();
	
	public void endGame();
	
	public void play(String sender, int position);

}
