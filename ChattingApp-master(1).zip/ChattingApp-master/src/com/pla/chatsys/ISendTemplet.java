package com.pla.chatsys;

public interface ISendTemplet {

	
	public void sendTemplet(String sender,String msgCode);
}
