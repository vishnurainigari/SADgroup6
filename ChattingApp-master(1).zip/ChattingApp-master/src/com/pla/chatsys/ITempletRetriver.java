package com.pla.chatsys;

public interface ITempletRetriver {
	
	public String[] getTemplet(String code);

}
