package com.pla.chatsys;

public interface IGameListener {
	
	public void gameStarted();
	
	public void gameEnded();
	
	public void played(String sender, int position);

}
