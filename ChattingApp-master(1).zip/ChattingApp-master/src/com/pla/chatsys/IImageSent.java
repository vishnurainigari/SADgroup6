package com.pla.chatsys;

public interface IImageSent {
	
	public void imageSent(String sender,String imageName,byte[] imageData);
}
