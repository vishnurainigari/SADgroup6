package com.pla.chatsys;

public interface IHistoryRetrive {

	
	public String retriveChatHistory(String sender);
}
