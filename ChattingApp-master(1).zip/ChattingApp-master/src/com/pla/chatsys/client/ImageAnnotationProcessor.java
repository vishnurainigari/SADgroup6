package com.pla.chatsys.client;

import japa.parser.JavaParser;
import japa.parser.ast.CompilationUnit;
import japa.parser.ast.body.MethodDeclaration;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;



public class ImageAnnotationProcessor {

/**
 * @param args
 * @throws Exception
 */
	public static void main(String[] args) throws Exception {
		
		String path = new File("src/com/pla/chatsys/client/ClientImp.java").getAbsolutePath();
		FileInputStream in = new FileInputStream(path);
		

		// parsing the annotated file
		
		CompilationUnit cu;
		try {
			
			cu = JavaParser.parse(in);
		} finally {
			in.close();
		}

		new MethodVisitor().visit(cu, null);
		
        
		// Writing the new annotated file
		String parsedFile = cu.toString();
		parsedFile = parsedFile.replace("void  ();", "");
				
		
		if(parsedFile.contains("public class ModifiedImage implements ActionListener {"+"\n"+"\n")) {
			System.out.println ("Got it");
			parsedFile = parsedFile.replace("public class ModifiedImage implements ActionListener {"+"\n"+"\n", "public class ModifiedImage implements ActionListener {");
			if (parsedFile.contains("public class ModifiedImage implements ActionListener {        "+"\n"+"    }")){
				parsedFile = parsedFile.replace("public class ModifiedImage implements ActionListener {        "+"\n"+"    }", "");
				
				parsedFile = parsedFile.replace("ImageButton.addActionListener(new ModifiedImage());","");
				parsedFile = parsedFile.replace("bottomPanel.add(ImageButton);","");
			}	
			else
				parsedFile = parsedFile.replace("public class ModifiedImage implements ActionListener {", "public class ModifiedImage implements ActionListener {"+"\n"+"\n");
		}
		else
			System.out.println ("Nope");
		
		//System.out.println ();
		PrintWriter print = new PrintWriter (path);
		print.println(parsedFile);
		print.close();
		
	}


	private static class MethodVisitor extends VoidVisitorAdapter {

		@Override
		public void visit(MethodDeclaration n, Object arg) {
    	
	
			if (n.getAnnotations() != null) {
			
				String getAnnotation = n.getAnnotations().toString();
				System.out.println (getAnnotation);		
				if (getAnnotation != null && getAnnotation.contains("Image")
						&& getAnnotation.contains("false")){
			
					n.setBody();
					n.setName();
					n.setModifiers(0);
					n.setThrows(null);
					n.setParameters(null);
				}
				
				if (getAnnotation.contains("Image"))
					n.setAnnotations(null);
			}
		}
	}
}
