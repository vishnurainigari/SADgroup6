package com.pla.chatsys.client;

import java.awt.print.PrinterException;

import javax.swing.JEditorPane;
import javax.swing.JOptionPane;

public class Printer {

	
	
}
