ChattingApp
===========

Chatting application used to show the Architecture Modeling on ArchStudio
